import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

/**
 * Created by hyx on 2016/10/6.
 */
public class Subset {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);
        String[] pool = new String[k];
        int i = 0;
        int size = 0;
        while (!StdIn.isEmpty()) {
            String s = StdIn.readString();
            if (size < k) {
                pool[size] = s;
                size++;
            } else {
                int r = StdRandom.uniform(0, i + 1);
                if (r < k)
                    pool[r] = s;
            }
            i++;
        }
        int[] index = new int[k];
        for (i = 0; i < k; i++) {
            index[i] = i;
        }
        StdRandom.shuffle(index);
        for (i = 0; i < k; i++) {
            StdOut.println(pool[index[i]]);
        }
    }
}
